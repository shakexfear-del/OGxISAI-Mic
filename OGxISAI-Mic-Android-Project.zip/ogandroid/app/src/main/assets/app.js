(() => {
  const startBtn = document.getElementById('startBtn');
  const stopBtn = document.getElementById('stopBtn');
  const statusDot = document.getElementById('statusDot');
  const statusText = document.getElementById('statusText');
  const timer = document.getElementById('timer');
  const errorBox = document.getElementById('errorBox');
  const hint = document.getElementById('micHint');

  let rawStream = null;
  let startedAt = 0;
  let timerId = null;

  function showError(err) {
    errorBox.textContent = err?.message || String(err);
    errorBox.classList.remove('hidden');
  }
  function clearError() { errorBox.classList.add('hidden'); errorBox.textContent = ''; }
  function format(ms) {
    const s = Math.floor(ms / 1000);
    return String(Math.floor(s / 60)).padStart(2,'0') + ':' + String(s % 60).padStart(2,'0');
  }
  function setRunning(running) {
    statusDot.classList.toggle('active', running);
    statusText.textContent = running ? 'Processing microphone' : 'Microphone stopped';
    startBtn.disabled = running;
    stopBtn.disabled = !running;
    hint.textContent = running
      ? 'OGxISAI processing is active. Use the tabs below to tune your voice.'
      : 'Start the microphone to activate the OGxISAI processing chain.';
  }

  async function startMic() {
    clearError();
    try {
      // injector.js replaces getUserMedia and builds the processed MediaStream.
      rawStream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false },
        video: false
      });
      startedAt = Date.now();
      timerId = setInterval(() => timer.textContent = format(Date.now() - startedAt), 250);
      setRunning(true);
      // Keep the source alive without routing it to speakers.
      window.__OGxISAI_MIC_STREAM__ = rawStream;
    } catch (err) {
      setRunning(false);
      showError('Microphone access failed. Check Windows microphone permissions and select a valid input device. ' + (err?.message || ''));
    }
  }

  function stopMic() {
    if (rawStream) rawStream.getTracks().forEach(t => t.stop());
    rawStream = null;
    window.__OGxISAI_MIC_STREAM__ = null;
    clearInterval(timerId); timerId = null; timer.textContent = '00:00';
    setRunning(false);
  }

  startBtn.addEventListener('click', startMic);
  stopBtn.addEventListener('click', stopMic);
  window.addEventListener('beforeunload', stopMic);

  // The injector builds its UI on the same document. Open the panel automatically.
  const openPanel = () => {
    const launcher = document.getElementById('bm-launcher');
    if (launcher) launcher.click();
  };
  setTimeout(openPanel, 700);
})();
